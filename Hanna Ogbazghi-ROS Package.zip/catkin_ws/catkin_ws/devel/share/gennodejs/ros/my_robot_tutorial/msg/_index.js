
"use strict";

let navigate2DGoal = require('./navigate2DGoal.js');
let navigate2DResult = require('./navigate2DResult.js');
let navigate2DActionGoal = require('./navigate2DActionGoal.js');
let Navigate2DActionResult = require('./Navigate2DActionResult.js');
let Navigate2DGoal = require('./Navigate2DGoal.js');
let Navigate2DActionGoal = require('./Navigate2DActionGoal.js');
let Navigate2DFeedback = require('./Navigate2DFeedback.js');
let navigate2DActionFeedback = require('./navigate2DActionFeedback.js');
let navigate2DAction = require('./navigate2DAction.js');
let Navigate2DActionFeedback = require('./Navigate2DActionFeedback.js');
let Navigate2DAction = require('./Navigate2DAction.js');
let navigate2DFeedback = require('./navigate2DFeedback.js');
let navigate2DActionResult = require('./navigate2DActionResult.js');
let Navigate2DResult = require('./Navigate2DResult.js');

module.exports = {
  navigate2DGoal: navigate2DGoal,
  navigate2DResult: navigate2DResult,
  navigate2DActionGoal: navigate2DActionGoal,
  Navigate2DActionResult: Navigate2DActionResult,
  Navigate2DGoal: Navigate2DGoal,
  Navigate2DActionGoal: Navigate2DActionGoal,
  Navigate2DFeedback: Navigate2DFeedback,
  navigate2DActionFeedback: navigate2DActionFeedback,
  navigate2DAction: navigate2DAction,
  Navigate2DActionFeedback: Navigate2DActionFeedback,
  Navigate2DAction: Navigate2DAction,
  navigate2DFeedback: navigate2DFeedback,
  navigate2DActionResult: navigate2DActionResult,
  Navigate2DResult: Navigate2DResult,
};
