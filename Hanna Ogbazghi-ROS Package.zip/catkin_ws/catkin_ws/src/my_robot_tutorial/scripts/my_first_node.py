import rospy

if __name__ == '__main__':
    #Creation of the node my_first_python_node
    rospy.init_node('my_first_python_node')
    #Printing information
    rospy.loginfo('This node has feedback')
    #Defining a rate (frequency)
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
        rospy.loginfo('Hello there')
        rate.sleep() #This will cause the "Hello there" msg to be displayed following the previously defined rate
