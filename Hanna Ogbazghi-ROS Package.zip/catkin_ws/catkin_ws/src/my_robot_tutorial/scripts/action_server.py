#!/usr/bin/env python3

#Importing necessary dependencies
import rospy
import actionlib
from my_robot_tutorial.msg import navigate2DAction, navigate2DFeedback, navigate2DResult #Typical Action files dependencies
from geometry_msgs.msg import Point
import math

class Navigate2DClass:
    def __init__(self):
        self.action_server = actionlib.SimpleActionServer("navigate_2D_action" , navigate2DAction , self.navigate_cb) #defining the name of topic of the action server, the action and the callback function
        self.robot_point_sub = rospy.Subscriber("robot/point" , Point , self.update_robot_position) #subscribing to the topic robot/point that would be provided through robot_point_pub.py by the user, defining the type and the callback function
        #This gives the current position of the robot and trigers the function update_robot_position that does what it's named after
        self.robot_current_point = None
        self.robot_goal_point = None
        self.distance_threshold = 0.35 #initialising some parameters
        self.feedback_rate = rospy.Rate(1) #Defining the feedback rate


    def navigate_cb(self,goal): #function to be called upon receiving a request from a client

        navigate_start_time = rospy.get_time() #getting the current time
        self.robot_goal_point = [goal.point.x, goal.point.y , goal.point.z] #setting the goal point upon receiving the information from the client



        while self.robot_current_point == None:
            print("Robot Point Not Detected") #Indicating whether or not the destination is reached
            rospy.sleep(5)
        print("Robot Point detected")
        distance_to_goal = math.dist(self.robot_current_point , self.robot_goal_point) #Computing the distance to the goal

        while distance_to_goal > self.distance_threshold: #While not reaching a certain distance from the goal

            self.action_server.publish_feedback(navigate2DFeedback(distance_to_point = distance_to_goal)) #publish a feedback about the current distance to the goal
            self.feedback_rate.sleep() #feedback rate
            distance_to_goal = math.dist(self.robot_current_point , self.robot_goal_point) #compute the distance again

        navigate_end_time = rospy.get_time() #get the time after the end of navigation
        elapsed_time = navigate_end_time - navigate_start_time #compute total navigation time
        rospy.loginfo("Navigate scucessfulm elapsed time " + str(elapsed_time) + " seconds") #Display the navigation time
        self.action_server.set_succeeded(navigate2DResult(elapsed_time)) #Set the result

    def update_robot_position(self, point):
        self.robot_current_point = [point.x , point.y , point.z] #Robot's position is updated upon receiving the information

if __name__ == '__main__':
    rospy.init_node("navigate_2D_action_sever_node") #Initialise the action server navigation node
    server = Navigate2DClass()
    rospy.spin()
