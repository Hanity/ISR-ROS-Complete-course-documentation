import rospy

from std_msgs.msg import String

def callback_function(data):
    print("Msg received: " + str(data))
    #A callback function that prints the received msg
def sub_function():
    rospy.init_node("sub_function_node") #Creation of the subscriber node
    pub = rospy.Subscriber('pub_msg',String, callback_function) #Defining the desired topic to subscribe to, the type of expected received msg and
    #a function launched upon receiving the msg from the publisher.



if __name__ == "__main__":
    sub_function()
    rospy.spin() #making the main code run in loops
