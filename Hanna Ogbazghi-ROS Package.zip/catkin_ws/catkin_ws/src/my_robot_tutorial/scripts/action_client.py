#!/usr/bin/env python3

import rospy
import actionlib
from my_robot_tutorial.msg import navigate2DAction, navigate2DFeedback, navigate2DResult,navigate2DGoal
from geometry_msgs.msg import Point
import math

def feedback_callback(feedback):
    print("Distance to Goal: " + str(feedback.distance_to_point)) #displaying the information received from the action service

def nav_client(user_coords):
    client = actionlib.SimpleActionClient("navigate_2D_action" , navigate2DAction) #defining the param of the service to call
    client.wait_for_server() #waiting for the service to be active

    point_msg = Point(x = user_coords[0], y = user_coords[1] , z = user_coords[2]) #the goal point
    goal = navigate2DGoal(point_msg) #setting the GOAL param
    client.send_goal(goal , feedback_cb = feedback_callback) #sending the GOAL (part of actionlib para) information while specifying a callback function
    client.wait_for_result() #waiting for the RESULT (part of actionlib para) to be set
    return client.get_result

if __name__ == '__main__':

        rospy.init_node("navigate_2D_action_client_node") #initialising our navigation action client
        #requesting the desired goal
        user_x = input("What is your desired x-coordinate?: ")
        user_y = input("What is your desired y-coordinate?: ")
        user_z = input("What is your desired z-coordinate?: ")

        user_coords = [float(user_x) , float(user_y) , float(user_z)]
        result = nav_client(user_coords) #calling the function nav_client to request a service from
        print(result)
