#!/usr/bin/env python3

import rospy
#Importing needed service dependencies request/response
from my_robot_tutorial.srv import OddEvenCheck, OddEvenCheckResponse



if __name__ == "__main__":
    try:
        rospy.init_node('odd_even_client_node') #Initialising our client node
        srv_proxy = rospy.ServiceProxy('odd_even_check',OddEvenCheck) #Specifying the service topic and name
        user_input = input('\n fill in with the number u want to know if is even or odd') #requesting input from the user
        resp_obj = srv_proxy(int(user_input)) #Calling the specified service asking if user_input is odd or even

        answer = resp_obj.answer #retrieving the response value since the server answer would be an object
        print(answer) #displaying the answer
    except rospy.ROSInterruptException:
        pass
