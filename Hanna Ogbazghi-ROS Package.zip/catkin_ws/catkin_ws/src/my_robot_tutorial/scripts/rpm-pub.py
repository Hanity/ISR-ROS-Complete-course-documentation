#!/usr/bin/env python3

#The line above helps the pc know that this code is supposed to be run using python3
import rospy
#Importing needed types of variables
from std_msgs.msg import Float32, String

def pub_function():
    rospy.init_node('node1') #Creating the node publishing the topic rpm
    pub = rospy.Publisher('rpm',Float32, queue_size=10) #specifying the topic "rpm", the msg type and the queue_size
    rate = rospy.Rate(5) #Defining the publishing rate for topic rpm
    while not rospy.is_shutdown():
        rpm = rospy.get_param("/wheel_radius") #get the wheel_radius para from ROS Parameter
        pub.publish(rpm) #publishing our msg
        rate.sleep() #Publish according to this rate

if __name__ == "__main__":
    try:
        pub_function() #launch the defined pub_function
    except rospy.ROSInterruptException:
        pass
