#!/usr/bin/env python3

import rospy
#Importing needed service dependencies request/response
from my_robot_tutorial.srv import OddEvenCheck, OddEvenCheckResponse

#defining the function deciding if a number is even or odd
def check_number(req):
    if (req.number % 2 == 0):
        check = 'even'
    else:
        check = 'odd'
    return OddEvenCheckResponse(check)

if __name__ == "__main__":
    try:
        rospy.init_node('odd_even_service_node') #Initialising our service node
        rospy.Service('odd_even_check',OddEvenCheck, check_number) #relating the service OddEvenCheck to the created node and specifying function
        # to call upon receiving a request from a client
        rospy.spin() #run the code in a loop
    except rospy.ROSInterruptException:
        pass
