#!/usr/bin/env python3
import os
import rospy
from my_robot_tutorial.srv import TurnCamera, TurnCameraResponse
import cv2
from cv_bridge import CvBridge


def configure_request(angle):
    rospy.wait_for_service("turn_camera") #waiting for the service turn_camera to be active
    try:

        service_proxy = rospy.ServiceProxy("turn_camera", TurnCamera) #defining the service param
        resp_msg = service_proxy(angle) #requesting the service (image) and storing it in the variable resp_msg
        image_msg = resp_msg.image #extracting the image from the object var
        image = CvBridge().imgmsg_to_cv2(image_msg, desired_encoding="passthrough") #converting the image from msg to normal
        #Displaying the image
        cv2.imshow("Turn image", image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    except rospy.ServiceException as e:
        print("Service request failed")
        print(e)

if __name__ == "__main__":
    try:
        rospy.init_node('turn_camera_client_node') #Initialising our client node
        user_input = input("\n Which camera angle do you want?") #Asking the user for an angle input

        while user_input !="q": #while the using haven't pressed q to quit do the following
            try:
                configure_request(float(user_input)) #Call the function that requests a service
                user_input = input("\n Which camera angle do you want?") #Asking the user for an angle input
            except:
                print("Error while trying to process request")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
