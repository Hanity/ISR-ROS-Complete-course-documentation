import rospy

from std_msgs.msg import String

#Defining a publisher function to be used in the main
def pub_function():
    rospy.init_node("pub_function_node") #Creation of the publisher node
    pub = rospy.Publisher('pub_msg',String, queue_size=10) #Defining the pub topic (pub_msg), the type of the pub msg and the queue_size

    i = 0
    rate = rospy.Rate(5) #Defining the publishing rate (frequency)
    while not rospy.is_shutdown():
        pub.publish("This is a published message" + str(i))
        i+=1
        rate.sleep() #Causes a periodical publishing (according to the rate)

if __name__ == "__main__":
    try:
        pub_function()#calling the previously defined pub function
    except rospy.ROSInterruptException: #in case of an error
        pass
