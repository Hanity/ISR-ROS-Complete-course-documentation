#!/usr/bin/env python3
import os
import rospy
from my_robot_tutorial.srv import TurnCamera, TurnCameraResponse
import cv2
from cv_bridge import CvBridge


class TurnCameraClass:
    def __init__(self):
        self.available_angles = [-30, -15, 0, 15, 30] #defining available image angles
        self.ros_service = rospy.Service("turn_camera", TurnCamera, self.send_img) #specifying the service topic, name and callback function

    def read_in_image_by_file_name(self, file_name):
        dir_name = os.path.dirname(__file__) #getting the current folder path
        file_location = dir_name + "/images/" + file_name #getting the complete image path
        image = cv2.imread(file_location) #reading the image
        return image

    def get_image(self,angle):
        closest_angle = min(self.available_angles, key=lambda x:abs(x-angle)) #This finds the closest image angle available compared to the request
        return self.read_in_image_by_file_name(str(closest_angle) + ".png") #returning the found image (calls the function above)
    def send_img(self,req):#This is the function to first be executed when the service received a request
        image = self.get_image(req.turn_degrees) #Calling the get_image function with a parameter turn_degrees (same as specified in TurnCamera.srv file)
        image_msg = (CvBridge().cv2_to_imgmsg(image)) #switching type to be able to send the img as a msg to the client
        return TurnCameraResponse(image_msg) #The msg to send to the client


if __name__ == "__main__":
    try:
        rospy.init_node('turn_camera_service_node') #Initialising our service node
        TurnCameraClass()
        print("TurnCamera service is running...")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
